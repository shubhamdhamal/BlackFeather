# Pacman.io

### Prérequis
 * Nodejs v10.15.0
### Installation
Pour installer les dépendances du projet :
```
 npm install
```
### Démarrage
Pour lancer le serveur :
```
 node server.js
```
### Capture d'écran
![home](https://florianvazelle.github.io/resources/images/pacman/home.png?raw=true)
![game](https://florianvazelle.github.io/resources/images/pacman/game.png?raw=true)